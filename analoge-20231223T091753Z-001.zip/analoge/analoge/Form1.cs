﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace analoge
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            

            //Выбор варианта банка плательщика
            List<string> states = new List<string>
             {  "ПАО «Лучший банк»", "ПАО «Главный банк»", "ПАО «Замечательный банк»"};
         

       
             // добавляем список элементов
             domainUpDown1.Items.AddRange(states);            
            domainUpDown1.TextChanged += domainUpDown2_SelectedItemChanged;
            // domainUpDown1.TextChanged += domainUpDown2_SelectedItemChanged;

            //Выбор варианта банка получателя
            List<string> states2 = new List<string>
             {  "ПАО «Лучший банк»", "ПАО «Главный банк»", "ПАО «Замечательный банк»" };



            // добавляем список элементов
            domainUpDown2.Items.AddRange(states2);
            domainUpDown2.TextChanged += domainUpDown2_SelectedItemChanged;
            domainUpDown2.Items.RemoveAt(0);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        //Кнопка отправки
        private void button2_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Вы уверены, что хотите отправить?",
                                         "Подтверждение отправки",
                                         MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                textBox1.Text = new Random().Next(0, 100).ToString();
                // Если 'Да', сделайте все поля недоступными для изменения.
                textBox1.Enabled = false;
                textBox2.Enabled = false;
                textBox3.Enabled = false;
                textBox4.Enabled = false;
                textBox5.Enabled = false;
                textBox6.Enabled = false;
                domainUpDown1.Enabled = false;
                domainUpDown2.Enabled = false;
                dateTimePicker1.Enabled = false;
                MessageBox.Show("Ваше платежное поручение принято к исполнению.",
                                                                             "Уведомление");
            }
            else
            {
                // Если 'Нет', выполните действие здесь.
            }
        }




        //Кнопка отмены
        private void button1_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Вы уверены, что хотите отменить?",
                                           "Подтверждение отмены",
                                           MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                // Если 'Да', очистите все поля.
                ClearTextBoxes(this);
                textBox1.Enabled = true;
                textBox2.Enabled = true;
                textBox3.Enabled = true;
                textBox4.Enabled = true;
                textBox5.Enabled = true;
                textBox6.Enabled = true;
                domainUpDown1.Enabled = true;
                domainUpDown2.Enabled = true;
                dateTimePicker1.Enabled = true;
                //класс статический меиод и гет
            }
            else
            {
                // Если 'Нет', выполните действие здесь.
            }


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        //Функция очистки полей
        private void ClearTextBoxes(Control parent)
        {
            foreach (Control c in parent.Controls)
            {
                if (c.GetType() == typeof(TextBox))
                {
                    ((TextBox)(c)).Text = string.Empty;
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            textBox4.KeyPress += textBox4_KeyPress;
            textBox4.MaxLength = 9;
            
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            textBox6.KeyPress += textBox6_KeyPress;
            textBox6.MaxLength = 20;
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void domainUpDown2_SelectedItemChanged(object sender, EventArgs e)
        {
            
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void domainUpDown1_SelectedItemChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            textBox5.KeyPress += textBox5_KeyPress;
            textBox5.MaxLength = 12;
        }
        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
